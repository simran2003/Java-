import java.util.ArrayList;
import java.util.HashMap;
import java.io.Serializable;


public class Customer implements Serializable  {
    private String name;
    private Double money;
    private HashMap<Product,Integer> purchase_count;//hash map to represent customer purchase

    public Customer(String name){
        this.name=name;
        purchase_count=new HashMap<>();
        money=0.0;
    }
    public String getName(){
        return name;
    }
    public void printPurchaseHistory(){
        String customer_purchase;
        for(Product p: purchase_count.keySet()) {//loop around the product names
            System.out.println(purchase_count.get(p) + "," + p);//print the product object, get return the value of p that is the no of products sold
        }
    }
    public void setMoney(double sold_amts) {//add the new money spent to the prev expenditure
        money= money+sold_amts;
    }
    public double getMoney() {
        return money;
    }
    public String toString(){
        //“{name} who has spent $x”
        return(name+" who has spent"+" "+money);
    }

    public void setPurchase(Product p, int amount) {
        if(this.purchase_count.containsKey(p)){// if the product has been bought before, simply increment the amount purchased
            this.purchase_count.put(p,this.purchase_count.get(p)+amount);
        }
        else{//else create a new spot for the product bought
            this.purchase_count.put(p, amount);
        }
    }


}
