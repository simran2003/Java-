//Class representing an electronic store
//Has an array of products that represent the items the store can sell
import java.util.*;
import java.io.*;
import java.io.Serializable;

public class ElectronicStore implements Serializable {//When allowing our own objects to be serialized, we must make
    //sure that all of the “pieces” of the object are also serializable.
    //Serialization is the process of breaking down an object into bytes.

    //public final int MAX_PRODUCTS = 10; //Maximum number of products the store can have
    private int curProducts;
    private String name;
    private ArrayList<Product> stock; //Array to hold all products
    private double revenue;
    private ArrayList<Customer> customer_list;

    public ElectronicStore(String initName){
        revenue = 0.0;
        name = initName;
        stock = new ArrayList<Product>();
        curProducts = 0;
        customer_list=new ArrayList<>();


    }

    public String getName(){
        return name;
    }


    //Adds a product and returns true if there is space in the array
    //Returns false otherwise
    public boolean addProduct(Product newProduct){
        for(Product p:stock) {
            if (p.toString().equals(newProduct.toString())){//if a duplicate product is found then return false and the code ends
                return false;
                //System.out.println("Current Products: " + curProducts);
            }
        }
        stock.add(newProduct);// incase it is not found return true and add it
        return true;
    }
    //add the given Customer
    //object to the ElectronicStore
    public boolean registerCustomer(Customer c1){
        //boolean result=true;
        for(Customer c: customer_list) { // same as adding products to the stock
            if(c.getName().equals(c1.getName())){
                return false;
                //System.out.println("Current Products: " + curProducts);
            }
        }
        customer_list.add(c1);
        return true;
    }
    //a List of Customer objects
    //that are registered with the ElectronicStore
    public List<Customer> getCustomers(){
        return customer_list;
    }
    //This method should return a list of registered customers
    public List<Product> searchProducts(String x){
        ArrayList<Product> searched_prod;// the list of products which match the to string with the given string
        searched_prod=new ArrayList<>();
        //int index = 0;
        for(Product p:stock){// search thro the list of stock simce they are already unique
            if(p.toString().toLowerCase().contains(x.toLowerCase())){//change both of them to lower case to check if they match
                searched_prod.add(p);
                //index++;
            }
        }
        //System.out.println("INDEX: "+ index);
        return searched_prod;
    }

    public List<Product> searchProducts(String x, double minPrice, double maxPrice) {
        ArrayList<Product> product_priceList;//list of matching products on the basis of price
        product_priceList=new ArrayList<>();
        //1.if both are negative the list is same as search products
        //2.if min price is more than max price but both are positive return null
        //3.if only max  price is negative then check the products price is more than min price
        //4. if only min price is negative check the products price is less than max price
        if(minPrice<0&&maxPrice<0){
            return searchProducts(x);
        }
        else if (minPrice>maxPrice&&maxPrice>=0&&minPrice>=0) {
            return null;
        }
        else if (minPrice<0&&maxPrice>=0){
            for(Product prod:searchProducts(x)){
                if(prod.getPrice()<= maxPrice){
                    product_priceList.add(prod);
                }
            }
            return  product_priceList;
        }
        else if (maxPrice<0&&minPrice>=0) {
            for(Product prod:searchProducts(x)){
                if(prod.getPrice()>= minPrice){
                    product_priceList.add(prod);
                }
            }
            return  product_priceList;
        }

        else { // for all other cases...
            for(Product prod:searchProducts(x)){
                if(minPrice <=prod.getPrice()&&prod.getPrice()<= maxPrice){
                    product_priceList.add(prod);
                }
            }
        }
        return product_priceList;
    }

    //If the given product exists in
    //the store, this method should increase the stock amount of that product by the included
    //amount.
    public boolean addStock(Product p, int amount){
        if(stock.contains(p)){// if it already has the product p then increase the quantity of stock by amount
            p.setStockQuantity(amount+p.getStockQuantity());
            return true;
        }
        return false;
    }
    public  boolean sellProduct(Product p, Customer c, int amount){
        if(customer_list.contains(c)&&stock.contains(p)&& p.getStockQuantity() >= amount){// even tho sell units checks wheteher the amount is less than the stock or not, it mused be checked here again because the sell units method just returns 0.0
            c.setMoney(p.sellUnits(amount));//sell units already calculates the price and deals with incrementing sold quantity and decreasing stock quantity
            c.setPurchase(p, amount);
            return true;
        }
        return false;
    }


    public List<Customer> getTopXCustomers(int x){
        ArrayList<Customer> sorted_customers;
        sorted_customers=new ArrayList<Customer>();
        //ArrayList<Customer> customerArrayList = new ArrayList<>();
        //sorted_customers.addAll(customer_list);

            // Compare whether Customer c1 comes before or after to Customer c2 based on amount spent
        Collections.sort(customer_list, new Comparator<Customer>() {
            //The method returns an int. This integer reflects the ordering
            //between the receiver and the parameter.
            public int compare(Customer c1, Customer c2) {
                    if (c1.getMoney() > c2.getMoney()){ // if c1 spent more money than c2  return -1
                        return -1;
                    }
                    if (c1.getMoney() < c2.getMoney()){ // if c1 spent less momey than c2, return 1
                        return 1;
                    }
                    else{return 0;} // else return 0 if both spent same amt
                }
            });

            if (x <= 0) {
                return null;
            }

            else if (x >= customer_list.size()) { // return all customers sorted
                return customer_list;
            }

            else {
                for (int i = 0; i < x; i++){ // loop x times to add x amount of sorted customers to the lsit of sorted customers
                    sorted_customers.add(customer_list.get(i));
                }
            }
        return sorted_customers;
    }

//implement and import serializable
    public boolean saveToFile(String filename){
        try {
            //ElectronicStore some_store;
            ObjectOutputStream out;
            out = new ObjectOutputStream(new FileOutputStream(filename));
            out.writeObject(this);
            out.close();
            return true;
        } catch (FileNotFoundException e) {
            System.out.println("Error: Cannot open file for writing");
            return false;
        } catch (IOException e) {
            System.out.println("Error: Cannot write to file");
            return false;
        }
    }
    public static ElectronicStore loadFromFile(String filename){
        try {
            ObjectInputStream in;
            in = new ObjectInputStream(new FileInputStream(filename));
            ElectronicStore electronic;
            electronic = (ElectronicStore) in.readObject();
            in.close();
            return electronic;

        }catch (ClassNotFoundException e) {
            return null;
        } catch  (FileNotFoundException e){
            return null;
        } catch (IOException e) {
            return null;
        }

    }

}
