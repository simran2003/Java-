import javafx.scene.control.Button;
import javafx.scene.layout.Pane;

public class DVDButtonPane extends Pane {
    private static Button addButton;
    private static Button deleteButton;

    public DVDButtonPane(){
        Pane aPane = new Pane();
        Button addButton = new Button("Add");
        addButton.relocate(10, 0);
        addButton.setPrefSize(90, 30);

        Button deleteButton = new Button("Delete");
        deleteButton.relocate(110, 0);
        deleteButton.setPrefSize(90, 30);

        Button statsButton = new Button("Stats");
        statsButton.relocate(220, 0);
        statsButton.setPrefSize(90, 30);

        addButton.setStyle("-fx-font: 12 arial; -fx-base: rgb(0,153,0); " +"-fx-text-fill: rgb(255,255,255));");
        deleteButton.setStyle("-fx-font: 12 arial; -fx-base: rgb(255,0,0); " +"-fx-text-fill: rgb(255,255,255));");
        statsButton.setStyle("-fx-font: 12 arial; -fx-base: rgb(192,192,192); " +"-fx-text-fill: rgb(255,255,255));");
        getChildren().addAll(addButton,deleteButton,statsButton);
        // Replace this with your own code

    }
    public static Button getAdd(){
        return addButton;
    }
    public static Button getDelete(){
        return deleteButton;
    }


}
