import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;
import javafx.scene.control.Label;
import java.awt.*;
import javafx.scene.control.ListView;
import javafx.scene.control.Button;
import javafx.stage.Stage;



public class DVDCollectionApp  extends Application {
    public void start(Stage primaryStage) {
        Pane  aPane = new Pane();
        primaryStage.setTitle("My DVD Collection"); // Set window title
        //primaryStage.setScene(scene);
       // primaryStage.show();

        // Create the labels
        Label label_Title = new Label("Title");
        label_Title.relocate(10, 20);
        label_Title.setPrefSize(80, 30);

        Label label_Year = new Label("Year");
        label_Year.relocate(225, 20);
        label_Year.setPrefSize(80, 30);

        Label label_length = new Label("Length");
        label_length.relocate(290, 20);
        label_length.setPrefSize(80, 30);

        // ... ADD CODE HERE ... //

        // Create the lists
        String[]    titles = {"Star Wars", "Java is cool", "Mary Poppins", "The Green Mile"};
        String[]    years = {"1978", "2002", "1968", "1999"};
        String[]    lengths = {"124", "93", "126", "148"};
        // ... ADD CODE HERE ... //
        ListView<String> titles_list;
        titles_list = new ListView<String>();
        titles_list.setItems(FXCollections.observableArrayList(titles));
        titles_list.relocate(10, 45);
        titles_list.setPrefSize(200, 150);

        ListView<String> years_list;
        years_list = new ListView<String>();
        years_list.setItems(FXCollections.observableArrayList(years));
        years_list.relocate(225, 45);
        years_list.setPrefSize(60, 150);

        ListView<String> length_list;
        length_list = new ListView<String>();
        length_list.setItems(FXCollections.observableArrayList(lengths));
        length_list.relocate(290, 45);
        length_list.setPrefSize(60, 150);

        // Create the buttons
        Button addButton = new Button("Add");
        addButton.relocate(10, 200);
        addButton.setPrefSize(95, 30);

        Button deleteButton = new Button("Delete");
        deleteButton.relocate(115, 200);
        deleteButton.setPrefSize(95, 30);

        Button statsButton = new Button("Stats");
        statsButton.relocate(290, 200);
        statsButton.setPrefSize(60, 30);
        // The following code shows how to set the font,
        // background color and text color of a button:
        addButton.setStyle("-fx-font: 12 arial; -fx-base: rgb(0,153,0); " +"-fx-text-fill: rgb(255,255,255));");
        deleteButton.setStyle("-fx-font: 12 arial; -fx-base: rgb(255,0,0); " +"-fx-text-fill: rgb(255,255,255));");
        statsButton.setStyle("-fx-font: 12 arial; -fx-base: rgb(192,192,192); " +"-fx-text-fill: rgb(255,255,255));");
        //     "-fx-text-fill: rgb(255,255,255);");
        //the 3 rgb values represent the red/green/blue values for the color your want
        // ... ADD CODE HERE ... //

        // Don't forget to add the components to the window, set the title,
        aPane.getChildren().addAll(titles_list, years_list,length_list ,addButton,deleteButton,statsButton,label_Title,label_Year,label_length);
        primaryStage.setScene(new Scene(aPane, 360,240)); // Set size of window

        // make it non-resizable, set Scene dimensions and then show the stage
        primaryStage.setResizable(false);
        primaryStage.show();
        // ... ADD CODE HERE ... //
    }

    public static void main(String[] args) {
        launch(args);
    }
}
