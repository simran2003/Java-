import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

public class DVDCollectionApp2  extends Application {
    private DVDCollection model;
    public DVDCollectionApp2(){

        model = DVDCollection.example1();
    }
    public void start(Stage primaryStage) {
        Pane  aPane = new Pane();

        // Create the labels
        Label label1 = new Label("DVDs");
        Label label2 = new Label("Title");
        Label label3 = new Label("Year");
        Label label4 = new Label("Length");
        label1.relocate(10,10);
        label2.relocate(10,202);
        label3.relocate(10,242);
        label4.relocate(120,242);

        // Create the TextFields
        TextField tField = new TextField();
        TextField yField = new TextField();
        TextField lField = new TextField();

        tField.relocate(50,200);
        tField.setPrefSize(500,30);

        yField.relocate(50,240);
        yField.setPrefSize(55,30);

        lField.relocate(180,240);
        lField.setPrefSize(45,30);

        // Create the lists
        ListView<DVD>    tList = new ListView<DVD>();
        tList.relocate(10,40);
        tList.setPrefSize(540,150);
        tList.setItems(FXCollections.observableArrayList(model.getDVDList()));

        //retrieve buttons


        // Create the buttons
        DVDButtonPane buttonPane = new DVDButtonPane();
        buttonPane.relocate(239,240);

        ObservableList<Node> child = buttonPane.getChildren();  //node c is contained within another node p, then c is called a child of p, and p is the parent of c.
        // getting  node objects stored in a list called child, stores the children of button pane, since button pane has add, delete, stats as buttons
        // getting the addbutton as first index object
        Button addButton = (Button) child.get(0);

        //action when addbutton is clicked
        addButton.setOnAction(new EventHandler<ActionEvent>() {
            //handle the event
            public void handle(ActionEvent event) {
                //gets the title, year, and length
                String dvd_name = tField.getText();
                int year  = Integer.parseInt(yField.getText());
                int length = Integer.parseInt(lField.getText());

                //adding a new dvd object
                DVD my_dvd = new DVD(dvd_name,year,length);
                //store it in the model
                model.add(my_dvd);
                //set it ; after getting th dvd list
                tList.setItems(FXCollections.observableArrayList(model.getDVDList()));

            }
        });
        Button deleteButton = (Button) child.get(1);
        //delete button is the child of button pane at index 2
        deleteButton.setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent event) {
                tList.getItems().remove(tList.getSelectionModel().getSelectedItem());//remove it from GUI

            }
        });
        tList.setOnMousePressed(new EventHandler<MouseEvent>() {
            public void handle(MouseEvent mouseEvent) {
                if((tList.getSelectionModel().getSelectedItem()!=null)){
                    tField.setText(tList.getSelectionModel().getSelectedItem().getTitle());
                    yField.setText(String.valueOf(tList.getSelectionModel().getSelectedItem().getYear()));
                    lField.setText(String.valueOf(tList.getSelectionModel().getSelectedItem().getDuration()));
                    model.remove(tList.getSelectionModel().getSelectedItem().getTitle());
                    tList.getItems().remove(tList.getSelectionModel().getSelectedItem());//remove it from GUI
                    // Add your code here
                }
                // Add your code here
            }
        });





        // Add all the components to the window
        aPane.getChildren().addAll(label1, label2, label3, label4, tField, yField,lField, tList, buttonPane);
        primaryStage.setTitle("My DVD Collection");
        primaryStage.setResizable(false);
        primaryStage.setScene(new Scene(aPane, 560,280));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
