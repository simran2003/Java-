import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import java.util.Scanner;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Pane;
import javafx.stage.Stage;

import javax.swing.*;


public class DVDCollectionApp1  extends Application {
    DVDCollection model;

    public DVDCollectionApp1() {
       // model=new DVDCollection();
        model=DVDCollection.example1();

    }

    public void start(Stage primaryStage) {
        Pane  aPane = new Pane();
        // Create the view
        DVDCollectionAppView1  view = new DVDCollectionAppView1();
        aPane.getChildren().add(view);

        primaryStage.setTitle("My DVD Collection");
        primaryStage.setResizable(false);
        primaryStage.setScene(new Scene(aPane));
        primaryStage.show();
        view.update(model, 0);
        view.getButtonPane().getAddButton().setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                System.out.print("Please enter your title: ");
                Scanner input = new Scanner(System.in);
                String title = input.next();
                System.out.print("Please enter the year: ");
                int year= input.nextInt();
                System.out.print("Please enter the duration: ");
                int length=input.nextInt();
                model.add(new DVD(title,year,length));
                view.update(model,0);
            }
        });

        view.getButtonPane().getDeleteButton().setOnAction(new EventHandler<ActionEvent>() {
            public void handle(ActionEvent actionEvent) {
                model.remove(view.getTitle());
                view.update(model,0);
            }
        });
        view.getTitleList().setOnMousePressed(new EventHandler<MouseEvent>(){
            public void handle(MouseEvent mouseEvent) {
                view.update(model,view.getSelectedIndex(view.getTitleList()));
            }
        });

        view.getTitleList().setOnMousePressed(new EventHandler<MouseEvent>(){
            public void handle(MouseEvent mouseEvent) {
                view.update(model,view.getSelectedIndex(view.getYearList()));
            }
        });

        view.getTitleList().setOnMousePressed(new EventHandler<MouseEvent>(){
            public void handle(MouseEvent mouseEvent) {
                view.update(model,view.getSelectedIndex(view.getLengthList()));
            }
        });


    }

    public static void main(String[] args) {
        launch(args);
    }
}