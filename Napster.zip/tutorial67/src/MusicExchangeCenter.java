
 import java.util.*;
// okay listen please write in the feedback the difference b/w list and array list and why it gives me an error if i write array list instead of list
 // pls i just wanna know; sorry to make u do extra work
public class MusicExchangeCenter {
    private List<User> users ;
    private HashMap<String, Float> royalties;
    private List<Song> downloadedSongs;

    public MusicExchangeCenter() {
        users = new ArrayList<User>();
        royalties=new HashMap<String,Float>();
        downloadedSongs=new ArrayList<Song>() ;
    }
    public List<User> onlineUsers(){
        List<User> online_users;              // the list of users who are online
        online_users= new ArrayList<User>();
        for(User u :users){    // for the user objects in the list of users iterate over the list of all  users
            if(u.isOnline()) { // if the user is online (is online method checks it) then add it to this list
                online_users.add(u);
            }
        }
        return online_users;
    }
    Song s;
    public List<Song> allAvailableSongs(){
        List<Song> songs_available = new ArrayList<Song>();
        for(User u: users){   // we need the song list of only those users who are online because those are the songs which are available to download by everyone else
            if(u.isOnline()) {
                for(Song s:u.getSongList()){//iterate over the list of songs of the users who are online and then add it to the list
                    songs_available.add(s);  // songs_available has the lists of songs that are available to download
                }
            }

        }
        return songs_available;
    }

    public String toString(){
        return "Music Exchange Center ("+onlineUsers().size()+" users online,"+allAvailableSongs().size()+" songs available)";
    }
    //"Music Exchange Center (3 users online, 15 songs available)").
    public User userWithName(String s){
        for(User u: users){   // iterate over the user list
            if(u.getUserName().equals(s)){  // checks whether the string s a username of some user u
                return u;
            }
        }
        return null;
    }
    public void registerUser(User x){
        if(userWithName(x.getUserName())==null){  // if such a user is not found then add it to the list of users
            users.add(x);    // this method will be used later
        }

    }
    public List<Song> availableSongsByArtist(String artist){
        ArrayList<Song> artist_songs;
        artist_songs = new ArrayList<Song>();
        for(Song s:allAvailableSongs()){ // check only the list of available songs because we already checked in allAvailableSongs() method whether the user is online or not
            if(s.getArtist().equals(artist)){
                artist_songs.add(s);
            }
        }
        return artist_songs;
    }
    public Song getSong(String title,String ownerName){
        for(User u :onlineUsers()){ // go thro the list of users who r online
            if(u.getUserName().equals(ownerName)) {  // check whether any of them matches the owner
                for(Song s:u.getSongList()){// if it does then user and owner are the same thing; iterate over it;s song list
                    if(s.getTitle().equals(title)){  // get the title of every single song
                        downloadedSongs.add(s);  // add it to downloaded songs
                       // downloadedSongs.add(s);
                        if(royalties.containsKey(s.getArtist())){ // if it is not the artist's first royalty then add 0.25 cents to the existing value
                            royalties.put(s.getArtist(),(float) (royalties.get(s.getArtist()) + 0.25)); // use the put method to set both key and value
                        }                                        // get the values of the artist key (value is  the money they have and add 0.25 to it)
                        else{
                            royalties.put(s.getArtist(), 0.25f);//(if it is the first time they get pais just give 0.25 cents)
                            //downloadedSongs.add(s);
                        }
                        return s;
                    }
                }
            }
        }
       return null;
    }
    public void displayRoyalties(){
        //if containsKey(Object k)
        //had at least one of their songs
        System.out.println("Amount\tArtist");
        System.out.println("----------------");
        for (String artist:royalties.keySet()){ // key set method gives u the whole list of keys
            System.out.println(String.format("$%3.2f\t%s",royalties.get(artist),artist)); // get the value of their money and print the artist name alongside
        }

    }
    public TreeSet<Song> uniqueDownloads(){
        return new TreeSet<>(downloadedSongs); // 1. implement comparable to the class which has the objects being compared
    }
    public ArrayList<Pair<Integer,Song>> songsByPopularity() {
        ArrayList<Pair<Integer,Song>> popular_songList;// the list which has these pairs as elements is song list
        popular_songList=new ArrayList<Pair<Integer,Song>>();
        HashMap<Song, Integer> popular_SongCount; // this counts the number of downloads
        popular_SongCount=new HashMap<Song, Integer>();
        for(Song s:downloadedSongs){  // iterate over the list of songs downloaded a
            if(popular_SongCount.containsKey(s)){//if the hash map already has that song as key
                popular_SongCount.put(s,(popular_SongCount.get(s)+1));// add 1 to the number of songs downloaded
            }
            else{
                popular_SongCount.put(s,1);// put 1 since this is the first time this song is being downloaded
            }
        }
        for(Song s:popular_SongCount.keySet()){ // go thro all the songs
            int downloads= popular_SongCount.get(s); // get their values i.e. their number of downloads
            Pair<Integer,Song> pairs= new Pair<Integer,Song>(downloads,s); // create pairs out of it
            popular_songList.add(pairs);
        }
        Collections.sort(popular_songList, new Comparator<Pair<Integer, Song>>() {
            public int compare(Pair<Integer, Song> p1, Pair<Integer, Song> p2) {
                return (p2.getKey().compareTo(p1.getKey())); // comparison
                // PUT YOUR CODE TO COMPARE p1 AND p2 IN HERE
            }
        });
        //System.out.println(popular_songList);
        return popular_songList;
    }

    public List<Song> getDownloadedSongs() { // returns the list of songs downloaded
        return downloadedSongs;
    }
}
