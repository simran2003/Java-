import java.util.*;
//import java.util.List;
public class User {
    private List<Song> songList;
    private String     userName;
    private boolean    online; //tells whether user is online or not

    public User()  { this(""); }

    public User(String u){
        userName = u;
        online = false;                    //initialise them
        songList = new ArrayList<Song>();
    }

    public String getUserName() { return userName; }
    public boolean isOnline() { return online; } // returns whether user is online or not

    public List<Song> getSongList() { return songList; } // this will be used to get the size of the array

    public String toString()  {
        String s = "" + userName + ":"+ songList.size() +" songs ("; //.size() gets the number of osngs in the list
        if (!online) s += "not ";
        return s + "online)";
    }
    public void addSong(Song s){
        songList.add(s);          // add songs to the list
        s.setOwner(this);
    }
    String s;
    public int totalSongTime(){
        int counter=0;
        for(Song s :songList){  // a for each loop which goes over the song objects in the list of songs and gets the seconds its played for
            //s.getSeconds();
            counter=counter+s.getSeconds();  // to get the total seconds
        }
        return counter;
    }
    public void register(MusicExchangeCenter m){
        m.registerUser(this); // this means the object in the cosntructor of this class( i think )
    }
    public void logon(){
        online=true;
    }
    public void logoff(){
        online=false;
    }
    public List<String> requestCompleteSonglist(MusicExchangeCenter m){
        List<String> Comp_list;
        Comp_list=new ArrayList<String>();
        int counter=0; // for the index
        Comp_list.add(String.format("%-30s%-20s%-7s%-1s","    TITLE","ARTIST","TIME","OWNER"));
        Comp_list.add("");
        for(Song s:m.allAvailableSongs()) {//  check avaiaible song list (it already checks for online users)
            Comp_list.add(String.format("%2d. %-25s%-20s%d:%02d  %-1s",++counter,s.getTitle(),s.getArtist(),s.getMinutes(),s.getSeconds(), s.getOwner().userName));
        }  // formatting gave me a headache
        return Comp_list;
    }
    public List<String> requestSonglistByArtist(MusicExchangeCenter m, String artist){
        List<String> Artist_list;
        Artist_list=new ArrayList<String>();
        int counter=0;
        Artist_list.add(String.format("%-30s%-20s%-7s%-1s","    TITLE","ARTIST","TIME","OWNER"));
        for(Song s:m.availableSongsByArtist(artist)) {//  check avaiaible song by artis list (it already checks for whether songs are available or not)
            Artist_list.add(String.format("%2d. %-25s%-20s%d:%02d  %-1s",++counter,s.getTitle(),artist,s.getMinutes(),s.getSeconds(), s.getOwner().userName));
        }
        return Artist_list;
    }
    public void downloadSong(MusicExchangeCenter m, String title,String ownerName){
        Song owner_song = m.getSong(title,ownerName);
        if (owner_song!=null) {
            //Song added_song = new Song(owner_song.getTitle(),owner_song.getArtist(),owner_song.getMinutes(),owner_song.getSeconds());
            //added_song.setOwner(this);
            songList.add(owner_song);
        }
    }


}

